INFORMATION...
  This pack is meant to be used with the Faithful 32x Resource Pack. Using this resource pack with the other resource pack may result in an odd-looking.

VERSIONS...
  1.14 to 1.20

 **IF THERE'S AN INCOMPATIBLE WARNING, JUST IGNORE IT — IT WILL BE FINE**

HOW TO INSTALL...
  1. Launch the game
  2. On the Game Main Menu, Go to 'Options... -> Resource Packs...'
  3. Click 'Open Pack Folder'
  4. Drag the Resource Packs file into the folder
  5. Now In Resource Packs Menu, Apply the resource pack.
  6. Enjoy the pack...

 **MAKE SURE THAT THIS ADD-ON IS ON TOP OF THE FAITHFUL RESOURCE PACK**

LICENSE:
This work is licensed under a Public Domain Dedication (CC0 1.0).
https://creativecommons.org/publicdomain/zero/1.0/

You don't have to credit me while you still can use this project as much as you would like.However, crediting me is still appreciated.
